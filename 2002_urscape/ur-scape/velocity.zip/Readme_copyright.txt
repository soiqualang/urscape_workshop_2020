Read me and copyright

This velocity (mm/year) file (velocity_vertical_HCMC_Dinh_RemoteSensing_Pub.tif)
is distributed as an product of the paper [1]. This was extrapolated with no respect of 
constraint features, i.e. rivers, to provide the full spatial coverage.

[1] Ho Tong Minh, D.; Le, V. T.; Le Toan, T. Mapping Ground Subsidence Phenomena
in Ho Chi Minh City through the Radar Interferometry Technique Using ALOS
PALSAR Data. Remote Sens. 2015, 7, 8543-8562.

Since it was reported in [1], an almost linear subsidence is taking place 
in Ho Chi Minh City for the period of 2006 to 2010. For instance, one can get the
displacement history by a typical formula :
	Displacement = velocity*T
where T is year unit. 	

If you use this dataset, please cite the paper [1] to credit our work.

Montpellier, 06 July 2015
Ho Tong Minh Dinh

